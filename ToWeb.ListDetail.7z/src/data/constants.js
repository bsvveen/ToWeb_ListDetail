
//export const apiUrl = 'http://towebjsonapi.azurewebsites.net/api';
export const apiUrl = 'http://localhost:62885/api/';

